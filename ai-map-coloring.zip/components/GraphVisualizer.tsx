import React from 'react';
import type { Graph, ColorMapping } from '../types';

interface GraphVisualizerProps {
  graph: Graph;
  colorMapping: ColorMapping;
  highlightedNode: string | null;
  colorPalette: string[];
}

const NODE_RADIUS = 25;
const HIGHLIGHT_RADIUS = 32;

export const GraphVisualizer: React.FC<GraphVisualizerProps> = ({
  graph,
  colorMapping,
  highlightedNode,
  colorPalette,
}) => {
  const { nodes, edges } = graph;

  const findNodeById = (id: string) => nodes.find(n => n.id === id);

  return (
    <svg width="100%" height="100%" viewBox="0 0 800 800" className="max-h-[80vh]">
      <g className="edges">
        {edges.map((edge, index) => {
          const sourceNode = findNodeById(edge.source);
          const targetNode = findNodeById(edge.target);
          if (!sourceNode || !targetNode) return null;

          let pathData: string;

          if (edge.path) {
            // Use the custom path if provided in the map definition
            pathData = edge.path;
          } else {
            // Fallback to the default curved line
            const sx = sourceNode.x;
            const sy = sourceNode.y;
            const tx = targetNode.x;
            const ty = targetNode.y;
  
            const mx = (sx + tx) / 2;
            const my = (sy + ty) / 2;
            const dx = tx - sx;
            const dy = ty - sy;
            const dist = Math.sqrt(dx * dx + dy * dy);
            
            const curveFactor = 30;
            const cx = mx - (dy / dist) * curveFactor;
            const cy = my + (dx / dist) * curveFactor;
  
            pathData = `M ${sx},${sy} Q ${cx},${cy} ${tx},${ty}`;
          }

          return (
            <path
              key={`${edge.source}-${edge.target}-${index}`}
              d={pathData}
              fill="none"
              className="stroke-gray-600"
              strokeWidth="3"
            />
          );
        })}
      </g>
      <g className="nodes">
        {nodes.map(node => {
          const colorIndex = colorMapping[node.id];
          const color = colorIndex !== null && colorIndex !== undefined 
            ? colorPalette[colorIndex % colorPalette.length] 
            : '#4b5563'; // gray-600
          const isHighlighted = highlightedNode === node.id;

          return (
            <g key={node.id} transform={`translate(${node.x},${node.y})`} className="transition-transform duration-200">
              {isHighlighted && (
                <circle
                  cx="0"
                  cy="0"
                  r={HIGHLIGHT_RADIUS}
                  className="fill-cyan-400/50"
                  style={{ transition: 'r 0.2s ease-in-out' }}
                >
                    <animate attributeName="r" from={NODE_RADIUS} to={HIGHLIGHT_RADIUS} dur="0.3s" fill="freeze" />
                </circle>
              )}
              <circle
                cx="0"
                cy="0"
                r={NODE_RADIUS}
                fill={color}
                className="stroke-gray-400"
                strokeWidth="2"
                style={{ transition: 'fill 0.3s ease' }}
              />
              <text
                textAnchor="middle"
                dy=".3em"
                className="fill-white font-bold text-lg select-none pointer-events-none"
              >
                {node.label}
              </text>
            </g>
          );
        })}
      </g>
    </svg>
  );
};