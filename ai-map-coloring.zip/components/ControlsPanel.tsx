import React, { useRef } from 'react';
import type { MapDefinition } from '../types';

interface ControlsPanelProps {
  maps: Record<string, MapDefinition>;
  selectedMapKey: string;
  onMapChange: (key: string) => void;
  numColors: number;
  onNumColorsChange: (value: number) => void;
  onSolve: () => void;
  onReset: () => void;
  isSolving: boolean;
  onCustomMapUpload: (map: MapDefinition) => void;
  onUploadError: (error: string) => void;
  uploadError: string | null;
  colorPalette: string[];
  onColorPaletteChange: (palette: string[]) => void;
}

const validateMapDefinition = (data: any): MapDefinition => {
  if (!data || typeof data !== 'object') {
    throw new Error("Invalid format. Expected a JSON object.");
  }

  if (!Array.isArray(data.nodes) || !Array.isArray(data.edges)) {
    throw new Error("Invalid structure. Must contain 'nodes' and 'edges' arrays.");
  }

  if (data.nodes.length === 0) {
    throw new Error("Map must contain at least one node.");
  }

  const nodeIds = new Set<string>();
  for (let i = 0; i < data.nodes.length; i++) {
    const node = data.nodes[i];
    if (
      !node ||
      typeof node.id !== 'string' ||
      typeof node.label !== 'string' ||
      typeof node.x !== 'number' ||
      typeof node.y !== 'number'
    ) {
      throw new Error(`Node at index ${i} has an invalid format. Expected {id: string, label: string, x: number, y: number}.`);
    }
    if (nodeIds.has(node.id)) {
        throw new Error(`Duplicate node ID found: '${node.id}'.`);
    }
    nodeIds.add(node.id);
  }

  for (let i = 0; i < data.edges.length; i++) {
    const edge = data.edges[i];
    if (!edge || typeof edge.source !== 'string' || typeof edge.target !== 'string') {
      throw new Error(`Edge at index ${i} has an invalid format. Expected {source: string, target: string}.`);
    }
    if (!nodeIds.has(edge.source)) {
      throw new Error(`Edge at index ${i} connects to a non-existent source node: '${edge.source}'.`);
    }
    if (!nodeIds.has(edge.target)) {
      throw new Error(`Edge at index ${i} connects to a non-existent target node: '${edge.target}'.`);
    }
  }

  return data as MapDefinition;
};


export const ControlsPanel: React.FC<ControlsPanelProps> = ({
  maps,
  selectedMapKey,
  onMapChange,
  numColors,
  onNumColorsChange,
  onSolve,
  onReset,
  isSolving,
  onCustomMapUpload,
  onUploadError,
  uploadError,
  colorPalette,
  onColorPaletteChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) {
      onUploadError("No file selected.");
      return;
    }

    if (file.type !== 'application/json') {
      onUploadError("Invalid file type. Please upload a JSON file.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result;
        if (typeof text !== 'string') {
          throw new Error("Failed to read file content.");
        }
        const data = JSON.parse(text);
        
        const validatedMap = validateMapDefinition(data);
        onCustomMapUpload(validatedMap);

      } catch (error) {
        if (error instanceof Error) {
          onUploadError(`Error parsing file: ${error.message}`);
        } else {
          onUploadError("An unknown error occurred while parsing the file.");
        }
      } finally {
        // Reset file input to allow re-uploading the same file
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      }
    };
    reader.onerror = () => {
      onUploadError("Failed to read the file.");
    };
    reader.readAsText(file);
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleColorChange = (index: number, newColor: string) => {
    const newPalette = [...colorPalette];
    newPalette[index] = newColor;
    onColorPaletteChange(newPalette);
  };
  
  const mapDisplayKeys = Array.from(new Set([...Object.keys(maps), 'custom']));

  return (
    <div className="flex flex-col gap-6">
      <div>
        <label htmlFor="map-select" className="block mb-2 text-sm font-medium text-cyan-300">
          1. Select a Map
        </label>
        <select
          id="map-select"
          value={selectedMapKey}
          onChange={(e) => onMapChange(e.target.value)}
          disabled={isSolving}
          className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-cyan-500 focus:border-cyan-500 block w-full p-2.5 disabled:opacity-50"
        >
          {mapDisplayKeys.map((key) => (
            <option key={key} value={key} className="capitalize">{key.replace(/_/g, ' ')}</option>
          ))}
        </select>
      </div>

      {selectedMapKey === 'custom' && (
        <div className="flex flex-col gap-2">
            <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="application/json"
                className="hidden"
                aria-hidden="true"
            />
            <button
                onClick={handleUploadClick}
                disabled={isSolving}
                className="w-full text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-800 font-medium rounded-lg text-sm px-5 py-2.5 transition-colors duration-200 disabled:opacity-50 flex items-center justify-center gap-2"
            >
                <i className="fas fa-upload"></i> Upload JSON Map
            </button>
            {uploadError && (
                <p className="text-sm text-red-400" role="alert">{uploadError}</p>
            )}
            {!uploadError && !maps.custom && (
                <p className="text-sm text-gray-400">Upload a JSON file with 'nodes' and 'edges'.</p>
            )}
        </div>
      )}

      <div>
        <label htmlFor="color-slider" className="block mb-2 text-sm font-medium text-cyan-300">
          2. Number of Colors: <span className="font-bold text-white">{numColors}</span>
        </label>
        <input
          id="color-slider"
          type="range"
          min="2"
          max="8"
          value={numColors}
          onChange={(e) => onNumColorsChange(parseInt(e.target.value))}
          disabled={isSolving}
          className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer disabled:opacity-50"
        />
      </div>

      <div>
        <label className="block mb-2 text-sm font-medium text-cyan-300">
          3. Customize Colors
        </label>
        <div className="grid grid-cols-4 gap-3">
            {colorPalette.map((color, index) => (
                <div key={index} className="relative w-full h-10 rounded-md overflow-hidden border-2 border-gray-500 focus-within:border-cyan-400 transition-colors">
                    <input
                        type="color"
                        value={color}
                        onChange={(e) => handleColorChange(index, e.target.value)}
                        disabled={isSolving}
                        className="absolute inset-0 w-full h-full cursor-pointer p-0 border-0 disabled:opacity-50"
                        title={`Color ${index + 1}`}
                        aria-label={`Color ${index + 1}`}
                    />
                </div>
            ))}
        </div>
      </div>

      <div className="flex flex-col gap-3 mt-2">
        <button
          onClick={onSolve}
          disabled={isSolving || !maps[selectedMapKey]}
          className="w-full text-white bg-cyan-600 hover:bg-cyan-700 focus:ring-4 focus:ring-cyan-800 font-medium rounded-lg text-sm px-5 py-3 transition-colors duration-200 disabled:bg-cyan-800 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isSolving ? (
            <>
              <i className="fas fa-spinner fa-spin"></i> Solving...
            </>
          ) : (
            <>
              <i className="fas fa-brain"></i> Color Map
            </>
          )}
        </button>
        <button
          onClick={onReset}
          disabled={isSolving}
          className="w-full text-white bg-gray-600 hover:bg-gray-700 focus:ring-4 focus:ring-gray-800 font-medium rounded-lg text-sm px-5 py-2.5 transition-colors duration-200 disabled:opacity-50"
        >
          <i className="fas fa-undo mr-2"></i> Reset
        </button>
      </div>
    </div>
  );
};