
import React, { useState, useEffect } from 'react';
import { fetchExplanation } from '../services/geminiService';

interface InfoPanelProps {
  status: string;
}

export const InfoPanel: React.FC<InfoPanelProps> = ({ status }) => {
  const [explanation, setExplanation] = useState<string>('Loading explanation...');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const getExplanation = async () => {
      setIsLoading(true);
      const text = await fetchExplanation();
      // Basic markdown to HTML conversion for Gemini response
      const htmlText = text
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n/g, '<br />');
      setExplanation(htmlText);
      setIsLoading(false);
    };

    getExplanation();
  }, []);

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h3 className="text-lg font-semibold text-cyan-300 mb-2">
          <i className="fas fa-info-circle mr-2"></i>Status
        </h3>
        <p className="bg-gray-700/50 p-3 rounded-md text-sm text-gray-300 h-16 overflow-y-auto">
          {status}
        </p>
      </div>
      <div>
        <h3 className="text-lg font-semibold text-cyan-300 mb-2">
          <i className="fas fa-book-open mr-2"></i>How It Works
        </h3>
        <div className="bg-gray-700/50 p-4 rounded-md text-sm text-gray-300 max-h-96 overflow-y-auto prose prose-invert prose-strong:text-cyan-400">
          {isLoading ? (
            <div className="flex items-center justify-center">
              <i className="fas fa-spinner fa-spin mr-2"></i> Loading explanation from Gemini...
            </div>
          ) : (
            <div dangerouslySetInnerHTML={{ __html: explanation }} />
          )}
        </div>
      </div>
    </div>
  );
};
