import type { MapDefinition } from '../types';

export const MAPS: Record<string, MapDefinition> = {
  australia: {
    nodes: [
      { id: 'WA', label: 'WA', x: 150, y: 300 },
      { id: 'NT', label: 'NT', x: 350, y: 200 },
      { id: 'SA', label: 'SA', x: 400, y: 400 },
      { id: 'QLD', label: 'QLD', x: 550, y: 250 },
      { id: 'NSW', label: 'NSW', x: 600, y: 450 },
      { id: 'VIC', label: 'VIC', x: 550, y: 600 },
      { id: 'TAS', label: 'TAS', x: 600, y: 750 },
    ],
    edges: [
      { source: 'WA', target: 'NT' },
      { source: 'WA', target: 'SA' },
      { source: 'NT', target: 'SA' },
      { source: 'NT', target: 'QLD' },
      { source: 'SA', target: 'QLD' },
      { source: 'SA', target: 'NSW' },
      { source: 'SA', target: 'VIC' },
      { source: 'QLD', target: 'NSW' },
      { source: 'NSW', target: 'VIC' },
    ],
  },
  simple: {
    nodes: [
      { id: 'A', label: 'A', x: 200, y: 200 },
      { id: 'B', label: 'B', x: 400, y: 200 },
      { id: 'C', label: 'C', x: 600, y: 200 },
      { id: 'D', label: 'D', x: 300, y: 400 },
      { id: 'E', label: 'E', x: 500, y: 400 },
    ],
    edges: [
      { source: 'A', target: 'B' },
      { source: 'A', target: 'D' },
      { source: 'B', target: 'C' },
      { source: 'B', target: 'D' },
      { source: 'B', target: 'E' },
      { source: 'C', target: 'E' },
      // This edge uses a custom SVG path to create an S-curve.
      { source: 'D', target: 'E', path: 'M 300,400 C 350,350 450,450 500,400' },
    ],
  },
  usa_west: {
    nodes: [
      { id: 'WA', label: 'WA', x: 150, y: 100 },
      { id: 'OR', label: 'OR', x: 150, y: 250 },
      { id: 'CA', label: 'CA', x: 150, y: 450 },
      { id: 'ID', label: 'ID', x: 300, y: 200 },
      { id: 'NV', label: 'NV', x: 300, y: 380 },
      { id: 'AZ', label: 'AZ', x: 350, y: 550 },
      { id: 'UT', label: 'UT', x: 450, y: 380 },
      { id: 'MT', label: 'MT', x: 450, y: 100 },
      { id: 'WY', label: 'WY', x: 550, y: 250 },
      { id: 'CO', label: 'CO', x: 600, y: 400 },
      { id: 'NM', label: 'NM', x: 580, y: 580 },
    ],
    edges: [
      { source: 'WA', target: 'OR' }, { source: 'WA', target: 'ID' },
      { source: 'OR', target: 'ID' }, { source: 'OR', target: 'NV' }, { source: 'OR', target: 'CA' },
      { source: 'CA', target: 'NV' }, { source: 'CA', target: 'AZ' },
      { source: 'ID', target: 'MT' }, { source: 'ID', target: 'WY' }, { source: 'ID', target: 'UT' }, { source: 'ID', target: 'NV' },
      { source: 'NV', target: 'UT' }, { source: 'NV', target: 'AZ' },
      { source: 'AZ', target: 'UT' }, { source: 'AZ', target: 'CO' }, { source: 'AZ', target: 'NM' },
      { source: 'UT', target: 'WY' }, { source: 'UT', target: 'CO' },
      { source: 'MT', target: 'WY' },
      { source: 'WY', target: 'CO' },
      { source: 'CO', target: 'NM' },
    ],
  }
};