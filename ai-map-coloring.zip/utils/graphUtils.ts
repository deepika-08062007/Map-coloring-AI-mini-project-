import type { Graph, MapDefinition } from '../types';

export const buildGraph = (mapDef: MapDefinition): Graph => {
  const adjacencyList: Record<string, string[]> = {};
  mapDef.nodes.forEach(node => {
    adjacencyList[node.id] = [];
  });
  mapDef.edges.forEach(edge => {
    adjacencyList[edge.source].push(edge.target);
    adjacencyList[edge.target].push(edge.source);
  });
  return {
    nodes: mapDef.nodes,
    edges: mapDef.edges,
    adjacencyList,
  };
};