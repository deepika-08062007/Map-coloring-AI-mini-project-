
import { GoogleGenAI } from "@google/genai";

export const fetchExplanation = async (): Promise<string> => {
  try {
    if (!process.env.API_KEY) {
      return "API_KEY environment variable not set. Please refer to the project's README for setup instructions.";
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const prompt = `
      Explain the Map Coloring Problem in the context of Artificial Intelligence and Computer Science. Cover the following points in a clear, well-structured format using markdown:
      1.  **What is the Map Coloring Problem?** Define it as a Constraint Satisfaction Problem (CSP).
      2.  **Graph Representation:** How is a map converted into a graph (nodes, edges)?
      3.  **The Backtracking Algorithm:** Explain step-by-step how backtracking is used to solve this problem. Use concepts like trying a color, checking for conflicts (constraints), and backtracking when a dead-end is reached.
      4.  **Why it's a Classic AI Problem:** Briefly touch on its importance in teaching search algorithms, constraints, and heuristics.
    `;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    return response.text;
  } catch (error) {
    console.error("Error fetching explanation from Gemini API:", error);
    return "Failed to load explanation. The AI model might be unavailable, or there could be an issue with the API key.";
  }
};
