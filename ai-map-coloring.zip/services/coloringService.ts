import type { Graph, ColorMapping, Step, Node } from '../types';

export function* solveMapColoringGenerator(
  graph: Graph,
  numColors: number
): Generator<Step, ColorMapping | null, void> {
  const colorMapping: ColorMapping = {};
  graph.nodes.forEach(node => {
    colorMapping[node.id] = null;
  });

  function isSafe(nodeId: string, color: number, currentMapping: ColorMapping): boolean {
    const neighbors = graph.adjacencyList[nodeId] || [];
    for (const neighborId of neighbors) {
      if (currentMapping[neighborId] === color) {
        return false;
      }
    }
    return true;
  }
  
  /**
   * Selects the next uncolored node to process using the
   * Minimum Remaining Values (MRV) heuristic. This implementation is robustly
   * tied to the `numColors` parameter.
   * @param currentMapping The current state of color assignments.
   * @returns The uncolored node with the fewest legal color options, or null if all nodes are colored.
   */
  function selectNextNode(currentMapping: ColorMapping): Node | null {
    const uncoloredNodes = graph.nodes.filter(node => currentMapping[node.id] === null);

    if (uncoloredNodes.length === 0) {
      return null;
    }

    // Map each uncolored node to an object containing the node and its count of remaining valid colors.
    const nodesWithRemainingValues = uncoloredNodes.map(node => {
      let remainingValues = 0;
      for (let c = 0; c < numColors; c++) {
        if (isSafe(node.id, c, currentMapping)) {
          remainingValues++;
        }
      }
      return { node, remainingValues };
    });

    // Sort the nodes based on their remaining values in ascending order.
    // The node with the minimum remaining values will be first.
    nodesWithRemainingValues.sort((a, b) => a.remainingValues - b.remainingValues);
    
    return nodesWithRemainingValues[0].node;
  }


  function* solve(): Generator<Step, boolean, void> {
    const currentNode = selectNextNode(colorMapping);
    
    if (currentNode === null) {
      // Base case: all nodes are successfully colored
      return true;
    }

    for (let c = 0; c < numColors; c++) {
      yield {
        type: 'TRY',
        nodeId: currentNode.id,
        mapping: { ...colorMapping },
      };

      if (isSafe(currentNode.id, c, colorMapping)) {
        colorMapping[currentNode.id] = c;
        yield {
          type: 'SUCCESS',
          nodeId: currentNode.id,
          mapping: { ...colorMapping },
        };

        const solved = yield* solve();
        if (solved) {
          return true;
        }

        // Backtrack if the recursive call didn't lead to a solution
        colorMapping[currentNode.id] = null;
        yield {
          type: 'BACKTRACK',
          nodeId: currentNode.id,
          mapping: { ...colorMapping },
        };
      }
    }

    // If no color worked for the current node, return false to trigger backtracking
    return false;
  }
  
  const solved = yield* solve();
  
  if (solved) {
    return colorMapping;
  } else {
    return null;
  }
}